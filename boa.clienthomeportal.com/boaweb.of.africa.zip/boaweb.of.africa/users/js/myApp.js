$(document).ready(function(){
	$(".menuIcon").click(function(){
    $("ul").toggle();
});

	
})

